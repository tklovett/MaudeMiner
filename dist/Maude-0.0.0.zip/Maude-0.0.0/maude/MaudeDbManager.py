import sqlite3
import re
import sys
import os
from random import choice
import MaudeSqlHelper

class MaudeDbManager():
    _tables = {}
    _maude_sql = MaudeSqlHelper.MaudeSqlHelper()

    __huh_messages = ["Huh?", "What?", "Come again?", "?",
                    "I don't understand.",
                    "I don't know what that means.",
                    "That's not even a real word.",
                    "Now you're just messing with me.",
                    "¿Hablas Inglés?", "Parlez-vous anglais?", "Sprechen Sie Englisch?"]
    __yes_messages = ["y", "yes"]
    __no_messages  = ["n", "no"]

    def __init__(self, arg=None):
        super(MaudeDbManager, self).__init__()
        self.arg = arg

        # connect to the database and look for tables
        self._tables = self._maude_sql.print_tables()

    def set_output(self, out):
        if out == "stdout":
            self._maude_sql.set_output_stdout(True)
        else:
            self._maude_sql.set_output(out)

    def create_tables(self):
        print("=== Creating Tables ===")
        print("Creating:")
        for file in os.listdir('schema'):
            if file.startswith("schema") and file.endswith(".sql"):
                # get table name
                table = file[file.find('_')+1:file.find(".")]
                print("\t" + table)
                # load schema
                with open("schema/"+file, 'r') as schema:
                    sql = schema.read()
                    self._maude_sql.execute(sql)
                # get number of columns in new table
                c = self.mConnection.execute("PRAGMA table_info(%s)" % table)
                numberOfColumns = len(c.fetchall())
                # add to table listing
                self._tables[table] = numberOfColumns
        # print(self._tables)
        print("=== Done ===\n")
        
    def print_table_info(self, reqTable=None):
        for table in self._tables:
            if (reqTable == None or table == reqTable):
                print(" == Info for Table %s ==\n" % table)
                self._maude_sql.execute("PRAGMA table_info(%s)" % table)
                self._maude_sql.print_results()


    def load_data_from_file(self, filename, table):
        print("Processing " + filename + "...")
        if table not in filename:
            print("This file does not seem to be associated with the specified table.")
            response = input("Are you sure you want to continue? (y/n) ")
            if response.lower() in __no_messages:
                return

        records = []
        invalidRecords = {}

        dataFile = open(filename, 'r')
        lines = dataFile.readlines()
        numlines = len(lines)
        print(str(numlines) + " records found")

        # build the sql statement
        numFields = self._tables[table]
        sql = "INSERT INTO %s VALUES (" % table
        sql += "?"
        for i in range(numFields-1):
            sql += ",?"
        sql += ")"
        # print(sql)

        # start loading animation
        print("|Loading..."+' '*41+"|")
        print("|", end='')
        sys.stdout.flush()

        # load each line
        for i in range(len(lines)):
            # write a '.' periodically
            if (i % int(numlines/50) == 0):
                print('.', end='')
                sys.stdout.flush()

            ok = self.insert_record_in_table(lines[i], table, records)
            if not ok:
                invalidRecords[i] = lines[i]

        print("|")

        # show invalid records        
        numInvalid = len(invalidRecords)
        if numInvalid != 0:
            invalidRecsFilename = "invalid_recs_" + filename[filename.rfind("/")+1:]
            print("Found %s invalid records. See %s" %(numInvalid, invalidRecsFile))
            with open(invalidRecsFilename, 'w') as invalidRecsFile:
                invalidRecsFile.write("Line    -> Record\n")
                invalidRecsFile.write("=================\n")
                for line, rec in invalidRecords.items():
                    msg = str(line) + " "*(7 - len(str(line))) + " -> " + rec
                    invalidRecsFile.write(msg)
                

        print("Executing...")
        self._maude_sql.execute(sql, records)
        print("Committing...")
        self.mConnection.commit()
        print("Done!")

    def insert_record_in_table(self, line, table, records):
        # preprocess the line
        line = line.strip("\n")
        
        # create the record tuple
        record = tuple(line.split('|'))

        # check that the record has the proper number of fields
        expectedNumFields = self._tables[table]
        if len(record) != expectedNumFields:
            return False

        # store the record for later execution
        records.append(record)

        return True

    def delete_all_data(self, table):
        print("=== Deleting Data From Table %s ===" % table)
        self._maude_sql.execute("DELETE from ?", table)
        print("=== Done ===\n")

    def load_all_data(self):
        print("=== Loading all data in data/txts/ ===")
        print("This will take a while. Why don't you go grab a coffee or something?")
        for file in os.listdir('data/txts/'):
            end = file.rfind('.')

            # determine appropriate table
            table = file[:end]
            while table not in self._tables and len(table) > 0:
                table = table[:len(table)-1]
            self.load_data_from_file("data/txts/"+file, table)
        print("=== Done ===\n")

    def setup(self):
        print("===== Running the Maude DB Setup (~20min) =====")
        import MaudeDownloader
        import MaudeSchemaBuilder

        download = True
        schema   = True
        load     = True

        # get user options
        i = input("Run Downloader?     (Y/n) ")
        if i.lower() in __no_messages:
            download = False
        i = input("Run Schema Builder? (Y/n) ")
        if i.lower() in __no_messages:
            schema = False
        i = input("Run Data Loader?    (Y/n) ")
        if i.lower() in __no_messages:
            laod = False

        print("\nGO!\n")
        if (download):
            MaudeDownloader.run()
        if (schema):
            MaudeSchemaBuilder.run()
        self._maude_sql.drop_tables()
        self.create_tables()
        if (load):
            self.load_all_data()
        print("===== Setup Complete! =====")

    def run(self):
        while (1):
            i = input("> ")
            cmds = i.split(" ")
            if i == "setup":
                self.setup()

            elif i.lower() in ["q", "quit", "exit"]:
                quit()
            
            elif i == "sql":
                self._maude_sql.go_interactive()
            
            elif i.startswith("info"):
                if len(cmds) < 2:
                    self.print_table_info()
                else:
                    for table in cmds:
                        if table == "info":
                            continue
                        self.print_table_info(table)
            
            elif cmds[0] == "stdout":
                if len(cmds) < 2 or cmds[1].lower() not in ["on", "off"]:
                    print("Usage is: 'stdout <on|off>'")
                    continue
                self._maude_sql.set_output_stdout(cmds[1].lower() == "on")

            elif i == "update":
                print("Yeah, that'd be nice, wouldn't it?")
            
            else:
                print(choice(self.__huh_messages))


if __name__ == "__main__":
    MaudeDbManager().run()
    
