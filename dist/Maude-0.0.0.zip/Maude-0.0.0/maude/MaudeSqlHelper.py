import sqlite3
import sys
from datetime import datetime

class MaudeSqlHelper(object):
    """Class for managing SQL interaction with the MAUDE database"""

    __connection = None
    __cursor = None
    __last_query = ""
    __output_stdout = True

    def __init__(self, arg=None):
        """Establish a connection to the database"""
        super(MaudeSqlHelper, self).__init__()
        self.arg = arg
        self.__connection = sqlite3.connect('maude.db')

    def __exit__(self, type, value, traceback):
        """Clean up on exit"""
        self.__connection.commit() # just in case
        self.__connection.close()

    def set_output_stdout(self, use_stdout):
        """specify whether to output to stdout or files"""

        if use_stdout:
            self.__output_stdout = True
            print("Output to stdout")
        else:
            self.__output_stdout = False
            print("Output to files")

    def go_interactive(self):
        while (1):
            sql = input("sqlite> ")

            if sql == "":
                continue

            # check if user is done with interactive mode
            if sql.lower() in ["q", "quit", "exit"]:
                return

            # execute sql
            success = self.execute(sql)
            if not success:
                print("Invalid SQLite statement.")
            else:
                self.print_results()

    def execute(self, sql, params=None):
        """ Execute a SQL query
            Returns True if the query executed successfully. Otherwise returns False."""

        try:
            if params != None and type(params) is list:
                self.__cursor = self.__connection.executemany(sql, params)
            elif params != None:
                self.__cursor = self.__connection.execute(sql, params)
            else:
                self.__cursor = self.__connection.execute(sql)
            self.__connection.commit()
            self.__last_query = sql
            if params != None:
                self.__last_query += "\n" + str(params)
        except:
            return False

        return True

    def print_results(self):
        """Print the results of the last SQL query"""
        if self.__cursor.rowcount > 500:
            i = input("Print all %s records? (y/N) " % self.__cursor.rowcount)
            if i.lower() not in ["y", "yes"]:
                return

        # get column names
        cols = []
        for col in self.__cursor.description:
            cols.append(col[0])
        # print(cols)

        # build template format string
        template = ""
        for i in range(len(cols)):
            template += "{%s:40}" % i
        template = template.replace("}{", "}|{")
        # print(template)

        # build output methodology
        output = sys.stdout
        if not self.__output_stdout:
            now = datetime.utcnow().strftime("%Y-%m-%d-%H%M%S")
            filename = "query_results_" + now + ".txt"
            output = open(filename, 'w')
        else:
            print("stdout")

        # print query
        output.write(self.__last_query + "\n")
        output.write("=" * len(self.__last_query) + "\n")

        # print header
        output.write(template.format(*tuple(cols)) + "\n") # header
        output.write("-"*41*len(cols) + "\n")

        # print records
        numRecs = 0
        for row in self.__cursor:
            if (numRecs == 100):
                i = input("100 records printed. Continue printing records? (y/N) ")
                if i.lower() not in ["y", "yes"]:
                    break
            output.write(template.format(*row) + "\n")
            numRecs += 1

        output.flush()
        if output != sys.stdout:
            output.close()
        print("-> %s records returned" % numRecs)

    def print_tables(self):
        """Print the tables currently contained in the database"""
        table_data = {}

        c = self.__connection.execute("SELECT name FROM sqlite_master WHERE type = 'table'")
        tables = c.fetchall()
        
        print("Found %s tables:" % len(tables))
        for t in tables:
            table = t[0]
            c = self.__connection.execute("PRAGMA table_info(%s)" % table)
            numberOfColumns = len(c.fetchall())
            print("\tName: "+table+"\tNum Columns: ", numberOfColumns)
            table_data[table] = numberOfColumns

        return table_data

    def drop_tables(self):
        print("=== Dropping Tables ===")
        # make sure the user wants to drop them all
        print("Ok, so you asked me to drop all the tables. This is serious. Irreversible. Permanent.")
        print("Well at least until you load the data again.")
        print("If you drop all the tables is going to take like 20 minutes to reload all the data.")
        print("Also its going to take at least 10 minutes just to drop the tables if the data has")
        print("already been loaded... so  yeah. Proceed with caution.")
        response = input("Are you sure you want to do that? (y/N) ")
        if response.lower() not in ["y", "yes"]:
            return

        # HERE COMES THE DROP
        print("Dropping:")
        tables = []
        for table in self.mTables:
            print("\t" + table)
            self._maude_sql.execute("DROP TABLE IF EXISTS %s" % table)
        print("=== Done ===\n")