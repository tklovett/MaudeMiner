from distutils.core import setup

setup(
    name='Maude',
    version='0.0.0',
    author='Thomas Lovett',
    author_email='tklovett@umich.edu',
    packages=['maude'],
    # scripts=['bin/stowe-towels.py','bin/wash-towels.py'],
    # url='http://pypi.python.org/pypi/Maude/',
    license='LICENSE.txt',
    description='A tool for analyzing the FDA\'s MAUDE dataset.',
    long_description=open('README.txt').read(),
    install_requires=[
        "SQLAlchemy >= 0.8.1",
    ],
)